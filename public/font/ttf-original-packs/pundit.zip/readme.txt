Pundit.
(c)2005 CJ's fonts Inc.
nznationalist@hotmail.com

>This font is free. Free to use in any way.
Thankyou for choosing PUNDIT as your latest 
font download. God Bless.__________________