
Writers
by Johan Waldenstr�m 2004

This is a freeware graffiti-inspired font, the first in the "Writers" serie.
If you want to use this font commercially, please contact me by e-mail; johanw82@gmail.com
I prefer a high point-size when using this font (72 or higher).
The font only has lower case characters, so make sure capslock isn�t on when using it.
Feel free to distribute this font, or any other one of my fonts. Do not sell them though.
For the latest versions of my fonts, see www.11-D.net

---

How to install:

Unzip the font into the fonts directory, located at c:\windows\fonts\

---

Have fun!


11-D productions | www.11-D.net