Rain & Neer - version 1.0
A display font made from watercolor brush strokes

Free for personal use.
Please consider to donate for commercial use. Paypal -- donations@niram.org

Created by Tharique Azeez
http://niram.org
twitter @enathu

Thank you for reading this readme file.
You're totally awesome!